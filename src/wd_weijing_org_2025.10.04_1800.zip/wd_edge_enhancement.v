//边缘增强
module edge_enhancement (
    input clk,                  // 像素时钟 (720p60约需74.25MHz)
    input rst_n,                // 异步复位，低有效
    
    // 输入视频信号
    input [23:0] RGB_in,           // 输入红色分量
    input vsync_in,             // 输入场同步信号
    input hsync_in,             // 输入行同步信号
    input de_in,                // 输入数据有效信号
    
    // 输出视频信号
    output [23:0] RGB_out,          // 输出红色分量
    output reg vsync_out,            // 输出场同步信号
    output reg hsync_out,            // 输出行同步信号
    output reg de_out                // 输出数据有效信号
);
wire [7:0] in_r,in_g, in_b;
assign in_r[7:0] = RGB_in[23:16];
assign in_g[7:0] = RGB_in[15: 8];
assign in_b[7:0] = RGB_in[ 7: 0];
reg [7:0] out_r,out_g,out_b;
assign RGB_out ={out_r[7:0],out_g[7:0],out_b[7:0]};

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        out_r[7:0] <=0;
        out_g[7:0] <=0;
        out_b[7:0] <=0;
        vsync_out <= 0;
        hsync_out <= 0;
        de_out <= 0;
    end else begin
        out_r[7:0] <= in_r[7:0];
        out_g[7:0] <= in_g[7:0];
        out_b[7:0] <= in_b[7:0];
        vsync_out <= vsync_in;
        hsync_out <= hsync_in;
        de_out <= de_in;
    end
end

/*
// 图像尺寸参数 (720p)
localparam H_ACTIVE = 1280;         // 水平有效像素
localparam V_ACTIVE = 720;          // 垂直有效像素
// 中间寄存器定义
reg [7:0] gray;                    // 灰度值
reg [7:0] line0 [0:H_ACTIVE-1];    // 存储第n行灰度值
reg [7:0] line1 [0:H_ACTIVE-1];    // 存储第n-1行灰度值
reg [7:0] line2 [0:H_ACTIVE-1];    // 存储第n-2行灰度值

// 行计数和列计数
reg [10:0] h_cnt;                  // 水平计数 (0~1279)
reg [10:0] v_cnt;                  // 垂直计数 (0~719)

// 同步信号延迟寄存器 (匹配图像处理延迟)
reg [2:0] vsync_dly;
reg [2:0] hsync_dly;
reg [2:0] de_dly;

// RGB转灰度 (采用ITU-R BT.601标准)
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        gray <= 8'd0;
    end else if (de_in) begin
        // 灰度 = 0.299*R + 0.587*G + 0.114*B
        gray <= (in_r * 77 + in_g * 150 + in_b * 29 + 128) >> 8;
    end
end

// 行缓存更新 (存储3行数据用于边缘检测)
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        h_cnt <= 11'd0;
        v_cnt <= 11'd0;
    end else if (de_in) begin
        // 水平计数
        if (h_cnt == H_ACTIVE - 1) begin
            h_cnt <= 11'd0;
            // 垂直计数
            if (v_cnt == V_ACTIVE - 1) begin
                v_cnt <= 11'd0;
            end else begin
                v_cnt <= v_cnt + 11'd1;
            end
        end else begin
            h_cnt <= h_cnt + 11'd1;
        end
        
        // 更新行缓存
        line0[h_cnt] <= gray;
        line1[h_cnt] <= line0[h_cnt];
        line2[h_cnt] <= line1[h_cnt];
    end
end

// 同步信号延迟 (与图像处理保持同步)
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        vsync_dly <= 3'd0;
        hsync_dly <= 3'd0;
        de_dly <= 3'd0;
    end else begin
        vsync_dly <= {vsync_dly[1:0], vsync_in};
        hsync_dly <= {hsync_dly[1:0], hsync_in};
        de_dly <= {de_dly[1:0], de_in};
    end
end

// Sobel边缘检测与增强
reg [10:0] gx, gy;         // 水平和垂直梯度
wire [10:0] g;                     // 梯度绝对值
reg [7:0] enhanced_r, enhanced_g, enhanced_b;
reg [7:0] delayed_r [0:2];         // RGB延迟线，匹配灰度处理延迟
reg [7:0] delayed_g [0:2];
reg [7:0] delayed_b [0:2];

// RGB信号延迟，与灰度处理保持同步
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        delayed_r[0] <= 8'd0;
        delayed_r[1] <= 8'd0;
        delayed_r[2] <= 8'd0;
        delayed_g[0] <= 8'd0;
        delayed_g[1] <= 8'd0;
        delayed_g[2] <= 8'd0;
        delayed_b[0] <= 8'd0;
        delayed_b[1] <= 8'd0;
        delayed_b[2] <= 8'd0;
    end else if (de_in) begin
        delayed_r[0] <= in_r;
        delayed_r[1] <= delayed_r[0];
        delayed_r[2] <= delayed_r[1];
        delayed_g[0] <= in_g;
        delayed_g[1] <= delayed_g[0];
        delayed_g[2] <= delayed_g[1];
        delayed_b[0] <= in_b;
        delayed_b[1] <= delayed_b[0];
        delayed_b[2] <= delayed_b[1];
    end
end

// 计算Sobel梯度 (3x3卷积)
// Gx = (P3 + 2*P6 + P9) - (P1 + 2*P4 + P7)
// Gy = (P7 + 2*P8 + P9) - (P1 + 2*P2 + P3)
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        gx <= 11'sd0;
        gy <= 11'sd0;
    end else if (de_dly[1] && h_cnt > 0 && h_cnt < H_ACTIVE - 1 && 
                v_cnt > 0 && v_cnt < V_ACTIVE - 1) begin
        // 水平梯度计算
        gx <= (line2[h_cnt-1] + {line2[h_cnt], 1'b0} + line2[h_cnt+1]) - 
              (line0[h_cnt-1] + {line0[h_cnt], 1'b0} + line0[h_cnt+1]);
        
        // 垂直梯度计算
        gy <= (line0[h_cnt-1] + {line1[h_cnt-1], 1'b0} + line2[h_cnt-1]) - 
              (line0[h_cnt+1] + {line1[h_cnt+1], 1'b0} + line2[h_cnt+1]);
    end else begin
        gx <= 11'sd0;
        gy <= 11'sd0;
    end
end

// 计算梯度绝对值并限制范围
assign g = (gx[10] ? -gx : gx) + (gy[10] ? -gy : gy);

// 边缘增强：原图 + 边缘信息 (带增益控制)
localparam EDGE_GAIN = 4'd1;        // 边缘增益，可调整
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        enhanced_r <= 8'd0;
        enhanced_g <= 8'd0;
        enhanced_b <= 8'd0;
    end else if (de_dly[2]) begin
        // 边缘增强公式：输出 = 原图 + 增益 * 边缘强度
        enhanced_r <= (delayed_r[2] + (g * EDGE_GAIN) >> 3) > 255 ? 255 : 
                     (delayed_r[2] + (g * EDGE_GAIN) >> 3) < 0 ? 0 : 
                     delayed_r[2] + (g * EDGE_GAIN) >> 3;
                     
        enhanced_g <= (delayed_g[2] + (g * EDGE_GAIN) >> 3) > 255 ? 255 : 
                     (delayed_g[2] + (g * EDGE_GAIN) >> 3) < 0 ? 0 : 
                     delayed_g[2] + (g * EDGE_GAIN) >> 3;
                     
        enhanced_b <= (delayed_b[2] + (g * EDGE_GAIN) >> 3) > 255 ? 255 : 
                     (delayed_b[2] + (g * EDGE_GAIN) >> 3) < 0 ? 0 : 
                     delayed_b[2] + (g * EDGE_GAIN) >> 3;
    end else begin
        enhanced_r <= delayed_r[2];
        enhanced_g <= delayed_g[2];
        enhanced_b <= delayed_b[2];
    end
end

// 输出信号赋值
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        out_r <= 8'd0;
        out_g <= 8'd0;
        out_b <= 8'd0;
        vsync_out <= 1'b0;
        hsync_out <= 1'b0;
        de_out <= 1'b0;
    end else begin
        out_r <= enhanced_r;
        out_g <= enhanced_g;
        out_b <= enhanced_b;
        vsync_out <= vsync_dly[2];
        hsync_out <= hsync_dly[2];
        de_out <= de_dly[2];
    end
end
*/
endmodule