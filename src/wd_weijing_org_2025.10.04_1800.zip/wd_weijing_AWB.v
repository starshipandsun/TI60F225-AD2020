`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/09/21
// Design Name: 
// Module Name: timer_system
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////
//白平衡_RGB
module wb_adjust (
    input clk,          // 像素时钟（约74.25 MHz for 720p60）
    input reset_n,      // 异步复位（低电平有效）
    input wire [23:0] rgb_in, // 输入RGB数据（R[23:16], G[15:8], B[7:0]）
    input vsync,        // 垂直同步信号（帧开始）
    input hsync,        // 水平同步信号（行开始）
    input de_in,  
    output reg [23:0] rgb_out, // 输出RGB数据
    output reg vsync_out,    // 输出垂直同步
    output reg hsync_out,    // 输出水平同步
    output reg de_out
);
 
// 状态机定义
//typedef enum {
localparam    IDLE              = 0;          // 空闲状态，等待帧开始
localparam    ACCUMULATE        = 1;    // 累加RGB值
localparam    CALC_AVG          = 2;      // 计算平均值 
localparam    APPLY             = 3;          // 应用增益到下一帧 
//} state_t;
reg [1:0] state;
 
// 内部寄存器 
reg [31:0] r_sum, g_sum, b_sum; // RGB累加器（32位防溢出）
reg [19:0] pixel_count;         // 像素计数器（最大921600 for 720p）
reg [7:0]  r_avg, g_avg, b_avg;  // RGB平均值
reg [15:0] r_gain, g_gain, b_gain; // 增益值（Q8.8定点格式）
reg [15:0] r_temp, g_temp, b_temp;
 
// 目标平均值（固定为128，基于灰度世界算法）
localparam TARGET_AVG = 8'd128;
 
// 状态机逻辑

always @(posedge clk or negedge reset_n) begin 
    if (!reset_n) begin 
        vsync_out <= 0;
        hsync_out <= 0;
        de_out <= 0;
    end else begin
        vsync_out <= vsync;
        hsync_out <= hsync;
        de_out <= de_in;
    end
end
always @(posedge clk or negedge reset_n) begin 
    if (!reset_n) begin 
        // 复位初始化 
        state <= IDLE;
        r_sum <= 0;
        g_sum <= 0;
        b_sum <= 0;
        pixel_count <= 0;
        r_avg <= 0;
        g_avg <= 0;
        b_avg <= 0;
        r_gain <= 16'h0100; // 初始增益1.0（Q8.8: 256 = 1.0）
        g_gain <= 16'h0100;
        b_gain <= 16'h0100;
        rgb_out <= 0;
    end else begin
        // 传递同步信号 
        case (state)
            IDLE: begin
                if (vsync) begin // 帧开始时进入累加状态
                    state <= ACCUMULATE;
                    r_sum <= 0;
                    g_sum <= 0;
                    b_sum <= 0;
                    pixel_count <= 0;
                end 
            end
 
            ACCUMULATE: begin
                if (!vsync) begin // 帧结束时进入计算状态
                    state <= CALC_AVG;
                    r_sum <= 0;
                    g_sum <= 0;
                    b_sum <= 0;
                    pixel_count <= 0;                    
                end else begin 
                    // 累加RGB值（忽略消隐区）
                    if (de_in && pixel_count < 20'd921600) begin
                        r_sum <= r_sum + rgb_in[23:16];
                        g_sum <= g_sum + rgb_in[15:8];
                        b_sum <= b_sum + rgb_in[7:0];
                        pixel_count <= pixel_count + 1;
                    end 
                end
            end 
 
            CALC_AVG: begin
                // 计算平均值（整帧）
                r_avg <= r_sum[31:8] / (pixel_count >> 8); // 近似除法（优化资源）
                g_avg <= g_sum[31:8] / (pixel_count >> 8);
                b_avg <= b_sum[31:8] / (pixel_count >> 8);
                state <= APPLY;
            end
 
            APPLY: begin
                if (vsync) begin // 下一帧开始时应用增益
                    // 计算增益（Q8.8格式：增益 = TARGET_AVG / avg，防除零）
                    r_gain <= (r_avg == 0) ? 16'h0100 : (TARGET_AVG * 256) / r_avg;
                    g_gain <= (g_avg == 0) ? 16'h0100 : (TARGET_AVG * 256) / g_avg;
                    b_gain <= (b_avg == 0) ? 16'h0100 : (TARGET_AVG * 256) / b_avg;
                    state <= IDLE;
                end
            end 
        endcase
 
        // 应用增益到当前像素（流水线处理）
        if (state == APPLY || state == ACCUMULATE) begin
            // 乘法调整（Q8.8乘法：结果右移8位）
            r_temp = (rgb_in[23:16] * r_gain) >> 8;
            g_temp = (rgb_in[15:8] * g_gain) >> 8;
            b_temp = (rgb_in[7:0] * b_gain) >> 8;
 
            // 饱和处理（限制在0-255）
            rgb_out[23:16] <= (r_temp > 255) ? 8'hFF : r_temp[7:0];
            rgb_out[15:8]  <= (g_temp > 255) ? 8'hFF : g_temp[7:0];
            rgb_out[7:0]   <= (b_temp > 255) ? 8'hFF : b_temp[7:0];
        end else begin
            rgb_out <= rgb_in; // 非应用状态直通
        end 
    end
end
endmodule 