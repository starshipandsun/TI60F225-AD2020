//AE_RGB
module auto_exposure (
    input clk,                  // 像素时钟 (720p60约需74.25MHz)
    input rst_n,                // 异步复位，低有效
    
    // 输入视频信号
    input [23:0] rgb_in,           // 输入红色分量
    input vsync_in,             // 输入场同步信号
    input hsync_in,             // 输入行同步信号
    input de_in,                // 输入数据有效信号
    
    // 输出视频信号
    output [23:0] rgb_out,          // 输出红色分量
    output reg vsync_out,            // 输出场同步信号
    output reg hsync_out,            // 输出行同步信号
    output reg de_out,                // 输出数据有效信号
    output reg [3:0]   analog_gain,      // 模拟增益控制 (0-15档)
    output reg [9:0]   exposure_time     // 曝光时间控制 (0-1023行)
);

wire [7:0] r_in,g_in, b_in;
assign r_in[7:0] = rgb_in[23:16];
assign g_in[7:0] = rgb_in[15: 8];
assign b_in[7:0] = rgb_in[ 7: 0];
reg [7:0] r_out,g_out,b_out;
assign rgb_out ={r_out[7:0],g_out[7:0],b_out[7:0]};

// 内部参数定义
parameter TARGET_BRIGHTNESS = 8'd128;   // 目标亮度值(0-255)
parameter BRIGHTNESS_TOLERANCE = 8'd10; // 亮度容差范围
parameter MAX_ANALOG_GAIN = 4'd15;      // 最大模拟增益
parameter MIN_ANALOG_GAIN = 4'd1;       // 最小模拟增益
parameter MAX_EXPOSURE = 10'd1023;      // 最大曝光时间
parameter MIN_EXPOSURE = 10'd10;        // 最小曝光时间
parameter GAIN_STEP = 4'd1;             // 增益调整步长
parameter EXPOSURE_STEP = 10'd20;       // 曝光时间调整步长
parameter FRAME_WIDTH = 10'd1280;       // 720p宽度
parameter FRAME_HEIGHT = 10'd720;       // 720p高度

// 状态机定义
localparam IDLE = 2'd0;
localparam ACCUMULATE = 2'd1;
localparam CALCULATE = 2'd2;
localparam ADJUST = 2'd3;

// 内部寄存器
reg [1:0] current_state, next_state;
reg [31:0] brightness_sum;              // 亮度总和
reg [20:0] pixel_count;                 // 像素计数
reg [7:0] avg_brightness;               // 平均亮度
reg vsync_d1, vsync_d2,vsync_out;                 // 同步信号边沿检测
reg hsync_d1,hsync_d2,hsync_out;
reg de_d1,de_d2,de_out;
//reg frame_valid;                        // 帧有效标志

// 边沿检测：检测vsync上升沿
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        vsync_out<=0; vsync_d2 <= 1'b0; vsync_d1 <= 1'b0;        
        hsync_out<=0; hsync_d2 <= 1'b0; hsync_d1 <= 1'b0;
        de_out<=0;    de_d2    <= 1'b0; de_d1    <= 1'b0;
    end else begin
        vsync_out <= vsync_d2; vsync_d2 <= vsync_d1; vsync_d1 <= vsync_in;
        hsync_out <= hsync_d2; hsync_d2 <= hsync_d1; hsync_d1 <= hsync_in;
        de_out    <= de_d2;    de_d2    <= de_d1;    de_d1    <= de_in;
    end
end

wire vsync_posedge = vsync_d1 & ~vsync_d2;  // vsync上升沿
//wire vsync_negedge = ~vsync_d1 & vsync_d2;  // vsync下降沿
//wire href_posedge = hsync_in & ~hsync_d1;        // href上升沿

// 状态机转换
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        current_state <= IDLE;
    end else begin
        current_state <= next_state;
    end
end

// 状态机逻辑
always @(*) begin
    case (current_state)
        IDLE: begin
            // 检测到帧开始，进入累积状态
            if (vsync_posedge) begin
                next_state = ACCUMULATE;
            end else begin
                next_state = IDLE;
            end
        end
        
        ACCUMULATE: begin
            // 累积完一帧像素后进入计算状态
            if (pixel_count >= FRAME_WIDTH * FRAME_HEIGHT) begin
                next_state = CALCULATE;
            end else begin
                next_state = ACCUMULATE;
            end
        end
        
        CALCULATE: begin
            // 完成亮度计算后进入调整状态
            next_state = ADJUST;
        end
        
        ADJUST: begin
            // 完成曝光调整后回到空闲状态
            next_state = IDLE;
        end
        
        default: next_state = IDLE;
    endcase
end

// 亮度累积：计算整帧平均亮度(Y = 0.299R + 0.587G + 0.114B)
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        brightness_sum <= 32'd0;
        pixel_count <= 20'd0;
    end else begin
        case (current_state)
            IDLE: begin
                brightness_sum <= 32'd0;
                pixel_count <= 20'd0;
            end
            
            ACCUMULATE: begin
                if (de_in) begin  // 行有效期间累积亮度
                    // 简化的亮度计算，避免浮点运算
                    brightness_sum <= brightness_sum + 
                                     (r_in * 8'd77 + g_in * 8'd150 + b_in * 8'd29) >> 8;
                    pixel_count <= pixel_count + 1'b1;
                end
            end
            
            default: begin
                brightness_sum <= brightness_sum;
                pixel_count <= pixel_count;
            end
        endcase
    end
end

// 计算平均亮度
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        avg_brightness <= 8'd0;
    end else if (current_state == CALCULATE) begin
        avg_brightness <= brightness_sum / pixel_count;  // 计算平均亮度
    end
end

// 自动曝光调整逻辑
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        analog_gain <= MIN_ANALOG_GAIN;
        exposure_time <= (MAX_EXPOSURE + MIN_EXPOSURE) >> 1;  // 初始曝光时间
    end else if (current_state == ADJUST) begin
        // 亮度低于目标值，增加曝光
        if (avg_brightness < (TARGET_BRIGHTNESS - BRIGHTNESS_TOLERANCE)) begin
            // 优先调整曝光时间
            if (exposure_time < MAX_EXPOSURE) begin
                exposure_time <= exposure_time + EXPOSURE_STEP;
            end else if (analog_gain < MAX_ANALOG_GAIN) begin
                analog_gain <= analog_gain + GAIN_STEP;  // 曝光时间达上限，增加增益
            end
        end
        // 亮度高于目标值，减少曝光
        else if (avg_brightness > (TARGET_BRIGHTNESS + BRIGHTNESS_TOLERANCE)) begin
            // 优先降低增益
            if (analog_gain > MIN_ANALOG_GAIN) begin
                analog_gain <= analog_gain - GAIN_STEP;
            end else if (exposure_time > MIN_EXPOSURE) begin
                exposure_time <= exposure_time - EXPOSURE_STEP;  // 增益达下限，减少曝光时间
            end
        end
        // 亮度在目标范围内，不调整
    end
end

// 应用数字增益到输出(补充模拟增益的不足)
reg [15:0] r_temp, g_temp, b_temp;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        r_out <= 8'd0;
        g_out <= 8'd0;
        b_out <= 8'd0;
    end else if (hsync_in) begin
        // 根据模拟增益计算数字增益补偿(简化为线性增益)
        r_temp = r_in * analog_gain;
        g_temp = g_in * analog_gain;
        b_temp = b_in * analog_gain;
        
        // 限幅处理，防止溢出
        r_out <= (r_temp > 16'd255) ? 8'd255 : r_temp[7:0];
        g_out <= (g_temp > 16'd255) ? 8'd255 : g_temp[7:0];
        b_out <= (b_temp > 16'd255) ? 8'd255 : b_temp[7:0];
    end else begin
        r_out <= 8'd0;
        g_out <= 8'd0;
        b_out <= 8'd0;
    end
end

endmodule