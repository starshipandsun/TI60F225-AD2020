//AE_RGB
module video_denoising (
    input clk,                  // 像素时钟 (720p60约需74.25MHz)
    input rst_n,                // 异步复位，低有效
    
    // 输入视频信号
    input [23:0] rgb_in,           // 输入红色分量
    input vsync_in,             // 输入场同步信号
    input hsync_in,             // 输入行同步信号
    input de_in,                // 输入数据有效信号
    
    // 输出视频信号
    output [23:0] rgb_out,          // 输出红色分量
    output reg vsync_out,            // 输出场同步信号
    output reg hsync_out,            // 输出行同步信号
    output reg de_out,                // 输出数据有效信号
    output reg [3:0]   analog_gain,      // 模拟增益控制 (0-15档)
    output reg [9:0]   exposure_time     // 曝光时间控制 (0-1023行)
);

wire [7:0] r_in,g_in, b_in;
assign r_in[7:0] = rgb_in[23:16];
assign g_in[7:0] = rgb_in[15: 8];
assign b_in[7:0] = rgb_in[ 7: 0];
reg [7:0] r_out,g_out,b_out;
assign rgb_out ={r_out[7:0],g_out[7:0],b_out[7:0]};

// 720p参数定义
localparam WIDTH  = 1280;  // 宽度
localparam HEIGHT = 720;   // 高度

// 帧缓存地址计算参数
localparam ADDR_WIDTH = 20; // 1280*720=921600 < 2^20
localparam PIXEL_DELAY = 3; // 滤波延迟

// 内部信号定义
reg [7:0] r_delay[0:PIXEL_DELAY-1];
reg [7:0] g_delay[0:PIXEL_DELAY-1];
reg [7:0] b_delay[0:PIXEL_DELAY-1];
reg [1:0] vsync_d, hsync_d, de_d;

// 空域滤波窗口 (3x3窗口)
reg [7:0] r_window[0:2][0:2];
reg [7:0] g_window[0:2][0:2];
reg [7:0] b_window[0:2][0:2];

// 帧缓存接口
wire [ADDR_WIDTH-1:0] wr_addr, rd_addr;
wire [23:0] wr_data, rd_data;
reg  we;  // 写使能

// 前一帧数据
reg [7:0] r_prev, g_prev, b_prev;

// 行计数器和列计数器
reg [10:0] row_cnt;
reg [10:0] col_cnt;

// 同步信号延迟对齐
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        vsync_out <= 1'b0; vsync_d <= 2'b00;
        hsync_out <= 1'b0; hsync_d <= 2'b00;
        de_out    <= 1'b0; de_d    <= 2'b00;
    end else begin
        vsync_out <= vsync_d[1]; vsync_d <= {vsync_d[0], vsync_in};
        hsync_out <= hsync_d[1]; hsync_d <= {hsync_d[0], hsync_in};
        de_out <= de_d[1]; de_d <= {de_d[0], de_in};
    end
end

// 行列计数
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        row_cnt <= 11'd0;
        col_cnt <= 11'd0;
    end else begin
        if (vsync_in) begin
            row_cnt <= 11'd0;
            col_cnt <= 11'd0;
        end else if (hsync_in) begin
            if (col_cnt == WIDTH - 1) begin
                col_cnt <= 11'd0;
                row_cnt <= row_cnt + 11'd1;
            end else begin
                col_cnt <= col_cnt + 11'd1;
            end
        end
    end
end

// 生成3x3空域窗口 (使用移位寄存器实现)
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        r_window[0][0] <= 8'd0;r_window[0][1] <= 8'd0;r_window[0][2] <= 8'd0;
        r_window[1][0] <= 8'd0;r_window[1][1] <= 8'd0;r_window[1][2] <= 8'd0;
        r_window[2][0] <= 8'd0;r_window[2][1] <= 8'd0;r_window[2][2] <= 8'd0;

        g_window[0][0] <= 8'd0;g_window[0][1] <= 8'd0;g_window[0][2] <= 8'd0;
        g_window[1][0] <= 8'd0;g_window[1][1] <= 8'd0;g_window[1][2] <= 8'd0;
        g_window[2][0] <= 8'd0;g_window[2][1] <= 8'd0;g_window[2][2] <= 8'd0;

        b_window[0][0] <= 8'd0;b_window[0][1] <= 8'd0;b_window[0][2] <= 8'd0;
        b_window[1][0] <= 8'd0;b_window[1][1] <= 8'd0;b_window[1][2] <= 8'd0;
        b_window[2][0] <= 8'd0;b_window[2][1] <= 8'd0;b_window[2][2] <= 8'd0;
        
    end else if (hsync_in) begin
        // 窗口移位更新
        r_window[0][0] <= r_window[0][1];
        r_window[0][1] <= r_window[0][2];
        r_window[0][2] <= r_window[1][2];
        r_window[1][0] <= r_window[1][1];
        r_window[1][1] <= r_window[1][2];
        r_window[1][2] <= r_window[2][2];
        r_window[2][0] <= r_window[2][1];
        r_window[2][1] <= r_window[2][2];
        r_window[2][2] <= r_in;
        
        // 绿色通道同样处理
        g_window[0][0] <= g_window[0][1];
        g_window[0][1] <= g_window[0][2];
        g_window[0][2] <= g_window[1][2];
        g_window[1][0] <= g_window[1][1];
        g_window[1][1] <= g_window[1][2];
        g_window[1][2] <= g_window[2][2];
        g_window[2][0] <= g_window[2][1];
        g_window[2][1] <= g_window[2][2];
        g_window[2][2] <= g_in;
        
        // 蓝色通道同样处理
        b_window[0][0] <= b_window[0][1];
        b_window[0][1] <= b_window[0][2];
        b_window[0][2] <= b_window[1][2];
        b_window[1][0] <= b_window[1][1];
        b_window[1][1] <= b_window[1][2];
        b_window[1][2] <= b_window[2][2];
        b_window[2][0] <= b_window[2][1];
        b_window[2][1] <= b_window[2][2];
        b_window[2][2] <= b_in;
    end
end

// 帧缓存地址计算
assign wr_addr = row_cnt * WIDTH + col_cnt;
assign rd_addr = row_cnt * WIDTH + col_cnt;  // 读取对应位置的前一帧数据
assign wr_data = {r_in, g_in, b_in};

// 从帧缓存读取前一帧数据
always @(posedge clk) begin
    r_prev <= rd_data[23:16];
    g_prev <= rd_data[15:8];
    b_prev <= rd_data[7:0];
end

// 帧缓存写控制
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        we <= 1'b0;
    end else begin
        we <= hsync_in;  // 有效像素期间写缓存
    end
end

// 空域高斯滤波计算 (3x3高斯核: [1 2 1; 2 4 2; 1 2 1] 总和=16)
reg [11:0] r_gauss, g_gauss, b_gauss;
always @(posedge clk) begin
    r_gauss <= r_window[0][0] + (r_window[0][1] << 1) + r_window[0][2] +
              (r_window[1][0] << 1) + (r_window[1][1] << 2) + (r_window[1][2] << 1) +
               r_window[2][0] + (r_window[2][1] << 1) + r_window[2][2];
    
    g_gauss <= g_window[0][0] + (g_window[0][1] << 1) + g_window[0][2] +
              (g_window[1][0] << 1) + (g_window[1][1] << 2) + (g_window[1][2] << 1) +
               g_window[2][0] + (g_window[2][1] << 1) + g_window[2][2];
    
    b_gauss <= b_window[0][0] + (b_window[0][1] << 1) + b_window[0][2] +
              (b_window[1][0] << 1) + (b_window[1][1] << 2) + (b_window[1][2] << 1) +
               b_window[2][0] + (b_window[2][1] << 1) + b_window[2][2];
end

// 计算当前帧与前一帧的差异
reg [7:0] r_diff, g_diff, b_diff;
always @(posedge clk) begin
    r_diff <= (r_in > r_prev) ? (r_in - r_prev) : (r_prev - r_in);
    g_diff <= (g_in > g_prev) ? (g_in - g_prev) : (g_prev - g_in);
    b_diff <= (b_in > b_prev) ? (b_in - b_prev) : (b_prev - b_in);
end

// 时空域联合降噪: 差异小时使用时域滤波，差异大时使用空域滤波
parameter DIFF_THRESHOLD = 8'd16;  // 差异阈值，可调整
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        r_out <= 8'd0;
        g_out <= 8'd0;
        b_out <= 8'd0;
    end else begin
        // 红色通道降噪
        if (r_diff < DIFF_THRESHOLD) begin
            // 时域滤波 (简单平均)
            r_out <= (r_in + r_prev) >> 1;
        end else begin
            // 空域高斯滤波结果
            r_out <= r_gauss[11:4];  // 除以16
        end
        
        // 绿色通道降噪
        if (g_diff < DIFF_THRESHOLD) begin
            g_out <= (g_in + g_prev) >> 1;
        end else begin
            g_out <= g_gauss[11:4];
        end
        
        // 蓝色通道降噪
        if (b_diff < DIFF_THRESHOLD) begin
            b_out <= (b_in + b_prev) >> 1;
        end else begin
            b_out <= b_gauss[11:4];
        end
    end
end

// 实例化双口RAM作为帧缓存
dual_port_ram #(
    .DATA_WIDTH(24),
    .ADDR_WIDTH(ADDR_WIDTH)
) frame_buffer (
    .clk(clk),
    .wr_en(we),
    .wr_addr(wr_addr),
    .wr_data(wr_data),
    .rd_addr(rd_addr),
    .rd_data(rd_data)
);

endmodule

// 双口RAM模块 (用于帧缓存)
module dual_port_ram #(
    parameter DATA_WIDTH = 24,
    parameter ADDR_WIDTH = 20
) (
    input wire                  clk,
    input wire                  wr_en,
    input wire [ADDR_WIDTH-1:0] wr_addr,
    input wire [DATA_WIDTH-1:0] wr_data,
    input wire [ADDR_WIDTH-1:0] rd_addr,
    output reg [DATA_WIDTH-1:0] rd_data
);

reg [DATA_WIDTH-1:0] ram [0:(1<<ADDR_WIDTH)-1];

always @(posedge clk) begin
    if (wr_en) begin
        ram[wr_addr] <= wr_data;
    end
    rd_data <= ram[rd_addr];
end

endmodule